module.exports = {
  // Default timeout value for 'waitFor..' commands
  waitForConditionTimeout: 5000,
  retryAssertionTimeout: 20000
}

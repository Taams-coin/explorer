class CryptoCompareService {
  async price (currency) {
    return 12.34
  }
}

export default new CryptoCompareService()

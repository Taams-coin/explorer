import BlockDetails from './Details'
import BlockIdentity from './Identity'
import BlockTransactions from './Transactions'

export {
  BlockDetails,
  BlockIdentity,
  BlockTransactions
}

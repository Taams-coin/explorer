import DelegateCount from './DelegateCount'
import LastBlock from './LastBlock'
import TotalForged from './TotalForged'

export {
  DelegateCount,
  LastBlock,
  TotalForged
}

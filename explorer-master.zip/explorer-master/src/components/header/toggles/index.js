import ToggleChart from './ToggleChart'
import ToggleCurrency from './ToggleCurrency'
import ToggleLanguage from './ToggleLanguage'
import ToggleTheme from './ToggleTheme'

export {
  ToggleChart,
  ToggleCurrency,
  ToggleLanguage,
  ToggleTheme
}

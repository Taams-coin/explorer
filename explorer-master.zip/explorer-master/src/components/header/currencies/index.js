import HeaderCurrenciesDesktop from './Desktop'
import HeaderCurrenciesMobile from './Mobile'

export {
  HeaderCurrenciesDesktop,
  HeaderCurrenciesMobile
}

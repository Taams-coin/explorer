import HeaderLanguagesDesktop from './Desktop'
import HeaderLanguagesMobile from './Mobile'

export {
  HeaderLanguagesDesktop,
  HeaderLanguagesMobile
}

import HeaderMenuDesktop from './Desktop'
import HeaderMenuMobile from './Mobile'

export {
  HeaderMenuDesktop,
  HeaderMenuMobile
}

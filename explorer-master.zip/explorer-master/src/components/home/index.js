import LatestBlocks from './LatestBlocks'
import LatestTransactions from './LatestTransactions'

export {
  LatestBlocks,
  LatestTransactions
}
